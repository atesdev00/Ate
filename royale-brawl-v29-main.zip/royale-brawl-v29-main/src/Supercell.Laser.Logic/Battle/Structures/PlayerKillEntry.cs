﻿namespace Supercell.Laser.Logic.Battle.Structures
{
    public struct PlayerKillEntry
    {
        public int PlayerIndex;
        public int BountyStarsEarned;
    }
}
