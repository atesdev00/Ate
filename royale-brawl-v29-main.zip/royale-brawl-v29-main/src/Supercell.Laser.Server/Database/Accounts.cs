namespace Supercell.Laser.Server.Database
{
    using MySql.Data.MySqlClient;
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Club;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Server.Database.Cache;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Settings;
    using Supercell.Laser.Server.Utils;

    public static class Accounts
    {
        private static long AvatarIdCounter;
        private static string ConnectionString;

        public static void Init(string user, string password)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "127.0.0.1";
            builder.UserID = user;
            builder.Password = password;
            builder.SslMode = MySqlSslMode.Disabled;
            builder.Database = Configuration.Instance.DatabaseName;
            builder.CharacterSet = "utf8mb4";
            builder.AllowPublicKeyRetrieval = true;

            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
            {
                DefaultValueHandling = DefaultValueHandling.Ignore,
                NullValueHandling = NullValueHandling.Ignore
            };
            ConnectionString = builder.ToString();

            AccountCache.Init();

            AvatarIdCounter = GetMaxAvatarId();
        }

        public static long GetMaxAvatarId()
        {
            using var Connection = new MySqlConnection(ConnectionString);
            Connection.Open();
            MySqlCommand command = new MySqlCommand(
                "SELECT coalesce(MAX(Id), 0) FROM accounts",
                Connection
            );

            long result = Convert.ToInt64(command.ExecuteScalar());
            Connection.Close();
            return result;
        }

        public static Account Create()
        {
            Account account = new Account();
            account.AccountId = ++AvatarIdCounter;
            account.PassToken = Helpers.RandomString(40);

            account.Avatar.AccountId = account.AccountId;
            account.Avatar.PassToken = account.PassToken;

            account.Home.HomeId = account.AccountId;

            NotificationFactory n = new();
            n.Add(
                new Notification
                {
                    Id = 83,
                    PrimaryMessageEntry = "<c00ff17>W<c00ff2e>E<c00ff45>L<c00ff5c>C<c00ff73>O<c00ff8b>M<c00ffa2>E<c00ffb9> <c00ffd0>T<c00ffe7>O<c00ffff> <c00ffff>T<c00e7ff>A<c00d0ff>R<c00b9ff>A<c00a2ff> <c008bff>B<c0073ff>R<c005cff>A<c0045ff>W<c002eff>L</c>",
                    SecondaryMessageEntry = "<c00ff0b>T<c00ff17>A<c00ff22>R<c00ff2e>A<c00ff39> <c00ff45>P<c00ff51>R<c00ff5c>E<c00ff68>M<c00ff73>İ<c00ff7f>U<c00ff8b>M<c00ff96> <c00ffa2>E<c00ffad>L<c00ffb9>M<c00ffc5>A<c00ffd0>S<c00ffdc> <c00ffe7>A<c00fff3>L<c00fffe>M<c00f3ff>A<c00e7ff>K<c00dcff> <c00d0ff>İ<c00c5ff>Ç<c00b9ff>İ<c00adff>N<c00a2ff> <c0096ff>T<c008bff>E<c007fff>L<c0073ff>E<c0068ff>G<c005cff>R<c0051ff>A<c0045ff>M<c0039ff> <c002eff>K<c0022ff>A<c0017ff>T<c000bff>I<c0008ff>L</c>)",
                    ButtonMessageEntry = "<c00bfff>T<c007fff>E<c003fff>L<c0000ff>E<c003fff>G<c007fff>R<c00bfff>A<c00ffff>M</c>",
                    FileLocation = "pop_up_1920x1235_welcome.png",
                    FileSha = "6bb3b752a80107a14671c7bdebe0a1b662448d0c",
                    ExtLint = "brawlstars://extlink?page=https%3A%2F%2Fgithub.com%2Ferder00",
                }
            );
            account.Home.NotificationFactory = n;

            Hero hero = new Hero(16000000, 23000000);
            account.Avatar.Heroes.Add(hero);

            string json = JsonConvert.SerializeObject(account);

            var Connection = new MySqlConnection(ConnectionString);
            Connection.Open();
            MySqlCommand command = new MySqlCommand(
                $"INSERT INTO accounts (`Id`, `Trophies`, `Data`) VALUES ({(long)account.AccountId}, {account.Avatar.Trophies}, @data)",
                Connection
            );
            command.Parameters?.AddWithValue("@data", json);
            command.ExecuteNonQuery();
            Connection.Close();

            AccountCache.Cache(account);

            return account;
        }

        public static void Save(Account account)
        {
            if (account == null)
                return;

            string json = JsonConvert.SerializeObject(account);

            var Connection = new MySqlConnection(ConnectionString);
            Connection.Open();
            MySqlCommand command = new MySqlCommand(
                $"UPDATE accounts SET `Trophies`='{account.Avatar.Trophies}', `Data`=@data WHERE Id = '{account.AccountId}'",
                Connection
            );
            command.Parameters?.AddWithValue("@data", json);
            command.ExecuteNonQuery();
            Connection.Close();
        }

        public static Account Load(long id)
        {
            if (AccountCache.IsAccountCached(id))
            {
                return AccountCache.GetAccount(id);
            }

            var Connection = new MySqlConnection(ConnectionString);
            Connection.Open();
            MySqlCommand command = new MySqlCommand(
                $"SELECT * FROM accounts WHERE Id = '{id}'",
                Connection
            );
            MySqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                Account account = JsonConvert.DeserializeObject<Account>((string)reader["Data"]);
                AccountCache.Cache(account);
                Connection.Close();
                return account;
            }
            Connection.Close();
            return null;
        }

        public static Account LoadNoChache(long id)
        {
            if (AccountCache.IsAccountCached(id))
            {
                return AccountCache.GetAccount(id);
            }

            var Connection = new MySqlConnection(ConnectionString);
            Connection.Open();
            MySqlCommand command = new MySqlCommand(
                $"SELECT * FROM accounts WHERE Id = '{id}'",
                Connection
            );
            MySqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                Account account = JsonConvert.DeserializeObject<Account>((string)reader["Data"]);
                Connection.Close();
                return account;
            }
            Connection.Close();
            return null;
        }

        public static List<Account> GetRankingList()
        {
            var list = new List<Account>();

            try
            {
                // fetch from cache
                var cachedAccounts = AccountCache.GetCachedAccounts();
                foreach (var account in cachedAccounts.Values)
                {
                    long allianceId = account.Avatar.AllianceId;
                    if (allianceId > 0)
                    {
                        Alliance alliance = Alliances.Load(allianceId);
                        if (alliance != null)
                        {
                            account.Avatar.AllianceName = alliance.Name;
                        }
                    }
                    list.Add(account);
                }

                // fetch from db
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();

                    using (
                        var cmd = new MySqlCommand(
                            $"SELECT * FROM accounts ORDER BY `Trophies` DESC LIMIT 200",
                            connection
                        )
                    )
                    {
                        var reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            var account = JsonConvert.DeserializeObject<Account>(
                                (string)reader["Data"]
                            );
                            long allianceId = account.Avatar.AllianceId;
                            if (allianceId > 0)
                            {
                                Alliance alliance = Alliances.Load(allianceId);
                                if (alliance != null)
                                {
                                    account.Avatar.AllianceName = alliance.Name;
                                }
                            }

                            // check if the account is already in the list (from cache)
                            if (!list.Any(a => a.AccountId == account.AccountId))
                            {
                                list.Add(account);
                            }
                        }
                    }

                    connection.Close();
                }

                list = list.OrderByDescending(a => a.Avatar.Trophies).ToList();

                if (list.Count > 200)
                {
                    list = list.GetRange(0, 200);
                }

                return list;
            }
            catch (Exception exception)
            {
                Logger.Error($"Error fetching leaderboard data: {exception.Message}");
                return list;
            }
        }

        public static Dictionary<int, List<Account>> GetBrawlersRankingList()
        {
            var list = new Dictionary<int, List<Account>>();
            List<int> Brawlers =
                new()
                {
                    0,
                    1,
                    2,
                    3,
                    4,
                    5,
                    6,
                    7,
                    8,
                    9,
                    10,
                    11,
                    12,
                    13,
                    14,
                    15,
                    16,
                    17,
                    18,
                    19,
                    20,
                    21,
                    22,
                    23,
                    24,
                    25,
                    26,
                    28,
                    29,
                    30,
                    31,
                    32,
                    33,
                    34,
                    35,
                    36,
                    37,
                    38,
                    39,
                    40
                };

            try
            {
                // fetch from cache
                var cachedAccounts = AccountCache.GetCachedAccounts();
                foreach (var account in cachedAccounts.Values)
                {
                    long allianceId = account.Avatar.AllianceId;
                    if (allianceId > 0)
                    {
                        Alliance alliance = Alliances.Load(allianceId);
                        if (alliance != null)
                        {
                            account.Avatar.AllianceName = alliance.Name;
                        }
                    }

                    foreach (Hero hero in account.Avatar.Heroes)
                    {
                        if (list.ContainsKey(hero.CharacterId))
                        {
                            list[hero.CharacterId].Add(account);
                        }
                        else
                        {
                            List<Account> a = new();
                            a.Add(account);
                            list.Add(hero.CharacterId, a);
                        }
                    }
                }

                // fetch from db
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand($"SELECT * FROM accounts", connection))
                    {
                        var reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            try
                            {
                                var account = JsonConvert.DeserializeObject<Account>(
                                    (string)reader["Data"]
                                );
                                long allianceId = account.Avatar.AllianceId;
                                if (allianceId > 0)
                                {
                                    Alliance alliance = Alliances.Load(allianceId);
                                    if (alliance == null)
                                    {
                                        continue;
                                    }
                                    account.Avatar.AllianceName = alliance.Name;
                                }

                                foreach (Hero hero in account.Avatar.Heroes)
                                {
                                    if (list.ContainsKey(hero.CharacterId))
                                    {
                                        if (
                                            !list[hero.CharacterId].Any(
                                                a => a.AccountId == account.AccountId
                                            )
                                        )
                                        {
                                            list[hero.CharacterId].Add(account);
                                        }
                                    }
                                    else
                                    {
                                        List<Account> a = new();
                                        a.Add(account);
                                        list.Add(hero.CharacterId, a);
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Logger.Error("LB Error" + e.ToString());
                            }
                        }
                    }

                    connection.Close();
                }

                foreach (var brawlerList in list.Values)
                {
                    brawlerList.Sort((a, b) => b.Avatar.Trophies.CompareTo(a.Avatar.Trophies));
                }

                return list;
            }
            catch (Exception exception)
            {
                Logger.Error($"Error fetching brawler leaderboard data: {exception.Message}");
                return list;
            }
        }
    }
}
