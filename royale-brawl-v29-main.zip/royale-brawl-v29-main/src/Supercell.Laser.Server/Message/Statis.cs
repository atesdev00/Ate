namespace Supercell.Laser.Server.Message
{
    public class Static
    {
        public static int USeed = 0;
    }
}