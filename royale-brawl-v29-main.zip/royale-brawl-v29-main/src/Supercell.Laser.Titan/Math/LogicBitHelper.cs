﻿namespace Supercell.Laser.Titan.Math
{
    internal class LogicBitHelper
    {
    }
}
